How to use it?

Don't forget to install the libz library. It is needed to read .cnf.gz files (compressed cnf). This is probably the most freqsuent compilation error.
You should type "make" into the simp (if you want to preprocess the file) or into the core directory.
You may have a few warning (depending on your gcc version) but this should not hurt
If Glucose compiles, you need now a CNF file to give it. CNF files are in Dimacs format, i.e. variables are numbers only and the formula is in conjunctive normal form. You may need to spend some time to search the web for this format. It is simple but you may need to write a few lines to handle it/play with it inside your own tool

To trust Glucose if it says "UNSAT" (your formula has no solution)
To run Glucose again with certified UNSAT activated (to check that glucose was correctly answer UNSAT)
To read the solution, if Glucose says "SAT". Your solution (with -model activated is printed at the end).

####
# Nosotros tuvimos que compilarlo poniendo glucose en la carpeta /home
# y hacer make en /core
####